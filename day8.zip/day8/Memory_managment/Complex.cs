﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memory_managment
{
    class Complex
    {

        public int real, img;


        public Complex()
        {
            real = 0;
            img = 0;
        }


        public void SetValue(int r, int i)
        {
            real = r;
            img = i;
        }


        public void DisplayValue()
        {
            Console.WriteLine("Real = " + real);
            Console.WriteLine("Imaginary = " + img);
        }


        ~Complex()
        {
            Console.WriteLine("Destructor was called");
        }
        /*internal class Factory
else
            {
                emp = GetNewEmployee();
                Console.WriteLine("Getting a new Employee:"+ Employee.counter+ "  Pool Count:" + objPool.Count);
            }
            return emp;
        }
        protected Employee RetriveFromPool()
        {
            Employee emp;
            if (objPool.Count > 0)
            {
                emp = (Employee)objPool.Dequeue();
                Employee.counter--;
                Console.WriteLine("Retrive from pool:"+emp.);
            }
            else
            {
                emp = new Employee();
            }
            return emp;
        }
        private Employee GetNewEmployee()
        {
            Employee emp = new Employee();
            objPool.Enqueue(emp);
            return emp;
        }
    }
From Karthik Suresh to Me (Direct Message) 01:19 PM
nternal class Employee
    {
        public static int counter = 0;
        public Employee()
        {
            ++counter;
        }
        private string firstName;
        private string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

    }

        in public static void main
Factory f = new Factory();
            f.GetEmployee();
            f.GetEmployee();
            f.GetEmployee();
            f.GetEmployee();
            f.GetEmployee();
            f.GetEmployee();
            f.GetEmployee();
            f.GetEmployee();

*/
    }
}
