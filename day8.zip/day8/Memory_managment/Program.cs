﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memory_managment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Complex c = new Complex();
            c.SetValue(2, 3);
            c.DisplayValue();
        }
    }
}
