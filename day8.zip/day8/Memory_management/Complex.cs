﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Memory_management
{

    class Compl
    {

       public  int real, img;

       
        public Compl() { 
            real = 0;
            img = 0;
        }

       
        public void SetValue(int r, int i)
        {
            real = r;
            img = i;
        }

       
        public void DisplayValue()
        {
            Console.WriteLine("Real = " + real);
            Console.WriteLine("Imaginary = " + img);
        }

        
        ~Compl()
        {
            Console.WriteLine("Destructor was called");
        }

    }
}
