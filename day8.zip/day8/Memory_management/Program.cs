﻿using System;

namespace Memory_management
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Compl c = new Compl();
            c.SetValue(2, 3);
            c.DisplayValue();
           //
        }
    }
}
