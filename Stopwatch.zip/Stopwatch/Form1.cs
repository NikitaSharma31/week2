﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stopwatch_demo
{
    public partial class Form1 : Form
    {
        float seconds;
        int minutes;
        int hours;
        int milisecond;
        public Form1()
        {
            InitializeComponent();
            milisecond = 0;
                seconds = minutes = hours = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }


        private void button2_Click(object sender, EventArgs e)
        {
            
            timer1.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            milisecond++;
            if (milisecond> 59)
            {
                seconds++;
                milisecond = 0;
            }
           
            if (seconds > 59)
            {
                minutes++;
                seconds = 0;
            }
            if (minutes > 59)
            {
                hours++;
                minutes = 0;
            }

            label1.Text = Append_zero(hours);
            label2.Text = Append_zero(minutes);
            label3.Text = Append_zero(seconds);
            label4.Text = Append_zero(milisecond);
        }


        public string Append_zero(double str)
        {
            if (str <= 9)

                return "0" + str;
            else
                return str.ToString();
            
        }
       

        private void button3_Click_1(object sender, EventArgs e)
        {

            timer1.Stop();
            hours = minutes = 0;
                seconds = 0;
            milisecond = 0;
           

            label1.Text = Append_zero(hours);
            label2.Text = Append_zero(minutes);
            label3.Text = Append_zero(seconds);
            label4.Text = Append_zero(milisecond);

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
