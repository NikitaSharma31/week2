﻿using System;

namespace Delegate_Single_Multi_Casting
{
    class Program
    {

       public delegate void DelMethod(int a, int b);

         public void multi(int a , int b)
         {
             Console.WriteLine("multiplication : {0}" , a*b);
         }

         public void div(int a, int b)
         {
             Console.WriteLine("division : {0}", a / b);
         }

         static void Main(string[] args)
         {
             Console.WriteLine("multiple delegate");

             Program obj = new Program();
             DelMethod del1 = new DelMethod(obj.multi);
             del1(4, 2);

             Console.WriteLine("after adding ");

             del1 += new DelMethod(obj.div);
             del1(6, 3);

         }

        /* public delegate void DelMethod(int x, int y);

        public void add(int x, int y)
        {
            Console.WriteLine("add is: {0}" , x+y);
        }
        public void sub(int x, int y)
        {
            Console.WriteLine("sub is: {0}", x - y);
        }

        static void Main(string[] args)
        {
            Console.WriteLine("single delegate");
            Program obj = new Program();
            DelMethod del1 = new DelMethod(obj.add);
            del1(3, 4);

            DelMethod del2 = new DelMethod(obj.sub);
            del2(8, 4);
        }*/
    }
}
